[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?style=flat)](https://github.com/ellerbrock/open-source-badges/)
![Dicoding](https://img.shields.io/badge/Dicoding-FrontEnd-blue?logo=github&color=%23F7DF1E)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg?logo=github&color=%23F7DF1E)](https://github.com/devancakra/Bookshelf-Apps/blob/master/LICENSE)
![GitHub last commit](https://img.shields.io/github/last-commit/devancakra/Bookshelf-Apps)
![HTML](https://img.shields.io/badge/HTML%20-light.svg?&style=flat&logo=html5&logoColor=%23F7DF1E&color=FF6347)
![CSS](https://img.shields.io/badge/CSS%20-light.svg?&style=flat&logo=css3&logoColor=%23F7DF1E&color=1E90FF)
![JS](https://img.shields.io/badge/Javascript%20-%23323330.svg?&style=flat&logo=javascript&logoColor=%23F7DF1E&color=008080)

<br>

# Bookshelf-Apps
Submission Dicoding Course - Belajar Membuat Front End Web untuk Pemula

<br>

# Cara penggunaan
1. Download repository ini

2. Cek Local Storage :
    <ul>
      <li> 
        Klik kanan pada area website lalu pilih -> inspeksi 
      </li>
      <li> 
        Cari Application -> Local Storage -> Lalu buat local storage
      </li>
     
      a. Key yang perlu anda buat :
            
       BOOKS_DATA
  
      b. Value yang perlu anda buat :
            
       []
            
      <li> Pastikan seperti gambar berikut :
        <img src = "https://user-images.githubusercontent.com/54527592/122673350-3966ce00-d1fa-11eb-8cdb-aa3acaed9280.png">
      </li>
    </ul>
    
3. Done! , selamat menikmati
      <img src = "https://user-images.githubusercontent.com/54527592/122670967-bab86380-d1ee-11eb-84d4-2006175d6f9f.png">
